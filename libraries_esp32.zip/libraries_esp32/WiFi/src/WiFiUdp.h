#pragma once
#include "NetworkUdp.h"
#define WiFiUDP NetworkUDP
