#pragma once
#include "NetworkClient.h"
#define WiFiClient NetworkClient
