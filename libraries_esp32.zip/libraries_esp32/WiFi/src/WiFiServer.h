#pragma once
#include "NetworkServer.h"
#define WiFiServer NetworkServer
